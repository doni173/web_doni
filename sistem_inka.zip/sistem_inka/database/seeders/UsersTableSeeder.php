<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'id_user' => 'US001',
            'nama_user' => 'wedi',
            'username' => 'admin',
            'password' => Hash::make('admin123'), // Password yang sudah di-hash
            'role' => 'Admin',
        ]);
    }
}
