<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Sistem Inventory dan Kasir</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body class="login">
    <div class="login-container">
        <h1>Sistem Inventory dan Kasir</h1>
        <p class="login-dtc-multimedia">DTC MULTIMEDIA</p>

        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="login-input-group">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="login-input-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div class="login-input-group">
                <input type="submit" value="Login">
            </div>
        </form>

        <?php if($errors->any()): ?>
            <div class="error">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\sistem_inka\resources\views/login.blade.php ENDPATH**/ ?>