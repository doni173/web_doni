<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penjualan | Sistem Inventory dan Kasir</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-all">
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4"><br>
            <h2>Transaksi Penjualan</h2>
        </div>

        <!-- Wrapper untuk tabel Daftar Barang dan Daftar Service -->
        <div class="table-wrapper">
            <!-- Daftar Barang -->
            <div class="table-container">
                <h3>Daftar Barang</h3>
                <form action="<?php echo e(route('sale.index')); ?>" method="GET" class="search-form">
                    <input type="text" class="form-control" placeholder="Cari barang..." name="q_barang" value="<?php echo e(request('q_barang')); ?>" style="width: 300px;">
                    <button type="submit" class="btn-src">Search</button>
                </form>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th>Harga</th>
                            <th>Diskon (%)</th>
                            <th>Harga Setelah Diskon</th>
                            <th>Jumlah</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->nama_produk); ?></td>
                            <td><?php echo e(number_format($item->harga_jual, 0, ',', '.')); ?></td>
                            <td><?php echo e($item->diskon); ?>%</td>
                            <td><?php echo e(number_format($item->harga_setelah_diskon, 0, ',', '.')); ?></td>
                            <td>
                                <input type="number" name="qty" class="form-control qty" data-id="<?php echo e($item->id_produk); ?>" value="1" min="1" max="100">
                            </td>
                            <td>
                                <button class="btn btn-success add-item" data-id="<?php echo e($item->id_produk); ?>" data-name="<?php echo e($item->nama_produk); ?>" data-price="<?php echo e($item->harga_jual); ?>" data-discount="<?php echo e($item->diskon); ?>">Tambah</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Daftar Service -->
            <div class="table-container">
                <h3>Daftar Service</h3>
                <form action="<?php echo e(route('sale.index')); ?>" method="GET" class="search-form">
                    <input type="text" class="form-control" placeholder="Cari service..." name="q_service" value="<?php echo e(request('q_service')); ?>" style="width: 300px;">
                    <button type="submit" class="btn-src">Search</button>
                </form>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Service</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($service->service); ?></td>
                            <td><?php echo e(number_format($service->harga, 0, ',', '.')); ?></td>
                            <td>
                                <input type="number" name="qty" class="form-control qty" data-id="<?php echo e($service->id_service); ?>" value="1" min="1" max="100">
                            </td>
                            <td>
                                <button class="btn btn-success add-service" data-id="<?php echo e($service->id_service); ?>" data-name="<?php echo e($service->service); ?>" data-price="<?php echo e($service->harga); ?>">Tambah</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Ringkasan Penjualan -->
        <h3>Ringkasan Penjualan</h3>
        <form action="<?php echo e(route('sale.store')); ?>" method="POST" id="sale-form">
            <?php echo csrf_field(); ?>
            
            <!-- Input Tanggal Otomatis -->
            <div class="form-group">
                <label for="tanggal_transaksi">Tanggal Transaksi</label>
                <input type="text" id="tanggal_transaksi" name="tanggal_transaksi" class="form-control" value="<?php echo e(now()->format('d-m-Y')); ?>" readonly>
            </div>

            <!-- Input Nama Customer -->
            <div class="form-group">
                <label for="nama_pelanggan">Nama Pelanggan_</label>
                <input type="text" id="nama_pelanggan" name="nama_pelanggan" class="form-control" required>
            </div>

            <table class="table table-striped" id="summary-table">
                <thead>
                    <tr>
                        <th>Produk / Service</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Diskon</th>
                        <th>Harga Setelah Diskon</th>
                        <th>Total Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody id="summary-body">
                    <!-- Data yang ditambahkan akan muncul di sini -->
                </tbody>    
            </table>

            <div class="form-group">
                <h4>Total Belanja: <span id="total_harga">Rp. 0</span></h4>
            </div>

            <div class="form-group">
                <label for="jumlah_bayar">Jumlah Bayar</label>
                <input type="number" id="jumlah_bayar" name="jumlah_bayar" class="form-control" required>
            </div>

            <div class="form-group">
                <h4>Kembalian: <span id="kembalian">Rp. 0</span></h4>
            </div>
            <input type="hidden" name="total_belanja" id="total_belanja_input">

            <input type="hidden" name="cart_data" id="cart_data">

            <button type="submit" class="btn btn-primary">Selesaikan Penjualan</button>
        </form>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    /* General Styles */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f4f4;
        color: #333;
    }

    .container-all {
        margin-top: 30px;
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .table-wrapper {
        display: flex;
        justify-content: space-between;
        gap: 20px;
    }

    .table-container {
        flex: 1;
    }

    .table {
        width: 100%;
        margin-top: 20px;
        border-collapse: collapse;
    }

    .table-striped tr:nth-child(odd) {
        background-color: #f9f9f9;
    }

    .table th, .table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .table th {
        background-color: #007bff;
        color: #fff;
    }

    .btn-success {
        background-color: #28a745;
        color: white;
    }

    .btn-success:hover {
        background-color: #218838;
    }

    .btn-src {
        background-color: #007bff;
        color: white;
    }

    .btn-src:hover {
        background-color: #0056b3;
    }

    .form-control {
        width: 100%;
        padding: 8px;
        font-size: 16px;
    }
</style>
<script>
    // ITEM
document.querySelectorAll('.add-item').forEach(btn => {
    btn.addEventListener('click', function () {
        const tr = this.closest('tr');
        const jumlah = parseInt(tr.querySelector('.qty').value);
        const diskon = parseFloat(this.dataset.discount);

        addToCart(
            'produk',
            this.dataset.id,
            this.dataset.name,
            parseInt(this.dataset.price),
            jumlah,
            diskon
        );
    });
});

// SERVICE
document.querySelectorAll('.add-service').forEach(btn => {
    btn.addEventListener('click', function () {
        const tr = this.closest('tr');
        const jumlah = parseInt(tr.querySelector('.qty').value);

        addToCart(
            'service',
            this.dataset.id,
            this.dataset.name,
            parseInt(this.dataset.price),
            jumlah
        );
    });
});

document.addEventListener('DOMContentLoaded', function () {
    // Load cart dari localStorage saat halaman pertama kali dimuat
    loadCartFromLocalStorage();
    updateSummary();
});

let cart = [];
let totalBelanja = 0;

// Fungsi untuk menyimpan cart ke localStorage
function saveCartToLocalStorage() {
    localStorage.setItem('salesCart', JSON.stringify(cart));
}

// Fungsi untuk memuat cart dari localStorage
function loadCartFromLocalStorage() {
    const savedCart = localStorage.getItem('salesCart');
    if (savedCart) {
        try {
            cart = JSON.parse(savedCart);
        } catch (e) {
            cart = [];
        }
    }
}

function updateSummary() {
    totalBelanja = 0;
    const tbody = document.getElementById('summary-body');
    tbody.innerHTML = '';

    cart.forEach(item => {
        const totalItem = item.harga_setelah_diskon * item.jumlah;
        totalBelanja += totalItem;

        tbody.innerHTML += `
            <tr>
                <td>${item.nama}</td>
                <td>Rp ${item.harga.toLocaleString('id-ID')}</td>
                <td>${item.jumlah}</td>
                <td>${item.diskon}%</td>
                <td>Rp ${item.harga_setelah_diskon.toLocaleString('id-ID')}</td>
                <td>Rp ${totalItem.toLocaleString('id-ID')}</td>
                <td><button class="btn btn-danger remove-item" data-id="${item.id}">Hapus</button></td>
            </tr>
        `;
    });

    document.getElementById('total_harga').innerText =
        'Rp. ' + totalBelanja.toLocaleString('id-ID');
        document.getElementById('cart_data').value = JSON.stringify(cart);
//document.getElementById('total_belanja_input').value = total;

    hitungKembalian();
}
function addToCart(type, id, nama, harga, jumlah, diskon = 0) {
    const harga_setelah_diskon = harga - (harga * (diskon / 100));

    if (type === 'produk') {
        cart.push({
            type: 'produk',
            id_produk: id,
            id_service: null,
            nama,
            harga,
            jumlah,
            diskon,
            harga_setelah_diskon
        });
    } else if (type === 'service') {
        cart.push({
            type: 'service',
            id_produk: null,
            id_service: id,
            nama,
            harga,
            jumlah,
            diskon: 0,
            harga_setelah_diskon
        });
    }

    saveCartToLocalStorage();
    updateSummary();
}

function removeFromCart(id) {
    const index = cart.findIndex(item => item.id === id);
    if (index !== -1) {
        cart.splice(index, 1);
    }
    
    // Simpan ke localStorage setiap kali ada perubahan
    saveCartToLocalStorage();
    updateSummary();
}

function hitungKembalian() {
    const bayar = parseInt(document.getElementById('jumlah_bayar').value) || 0;
    let kembali = bayar - totalBelanja;
    if (kembali < 0) kembali = 0;

    document.getElementById('kembalian').innerText =
        'Rp. ' + kembali.toLocaleString('id-ID');
}

document.getElementById('jumlah_bayar')
    .addEventListener('input', hitungKembalian);

// ITEM
document.querySelectorAll('.add-item').forEach(btn => {
    btn.addEventListener('click', function () {
        const tr = this.closest('tr');
        const jumlah = parseInt(tr.querySelector('.qty').value);
        const diskon = parseFloat(this.dataset.discount);

        addToCart(
            this.dataset.id,
            this.dataset.name,
            parseInt(this.dataset.price),
            jumlah,
            diskon
        );
    });
});

// SERVICE
document.querySelectorAll('.add-service').forEach(btn => {
    btn.addEventListener('click', function () {
        const tr = this.closest('tr');
        const jumlah = parseInt(tr.querySelector('.qty').value);

        addToCart(
            this.dataset.id,
            this.dataset.name,
            parseInt(this.dataset.price),
            jumlah,
            0 // Tidak ada diskon untuk service
        );
    });
});

// REMOVE ITEM
document.getElementById('summary-body').addEventListener('click', function (e) {
    if (e.target && e.target.classList.contains('remove-item')) {
        const itemId = e.target.dataset.id;
        removeFromCart(itemId);
    }
});
</script>

</body>
</html>
<?php /**PATH C:\laragon\www\sistem_inka\resources\views/sale.blade.php ENDPATH**/ ?>