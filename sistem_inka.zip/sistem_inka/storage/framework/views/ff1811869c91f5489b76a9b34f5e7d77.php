<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Merk | Sistem Inventory dan Kasir</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="dashboard-container">
    <div class="container">
        
        <h2>Daftar Merk</h2>

        <!-- Form Pencarian -->
        <div class="input-group mb-4">
            <form action="<?php echo e(route('brands.index')); ?>" method="get" class="form-inline">
                <input type="text" name="search" class="form-control mr-2" placeholder="Cari merk..." value="<?php echo e(request()->get('search')); ?>">
                <button type="submit" class="btn btn-primary">Cari</button>
            </form>
            <div class="add-button-container mt-3">
                <!-- Tombol untuk membuka modal tambah data -->
                <button class="btn btn-success" data-toggle="modal" data-target="#addModal">Tambah Data</button>
            </div>
        </div>

        <!-- Container untuk tabel -->
        <div class="category-table-container">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID Merk</th>
                        <th>Brand</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($brand->id_brand); ?></td>
                            <td><?php echo e($brand->brand); ?></td>
                            <td>
                                <!-- Tombol Edit untuk membuka modal -->
                                <button class="btn btn-warning btn-edit" data-toggle="modal" data-target="#editModal" data-id="<?php echo e($brand->id_brand); ?>" data-nama="<?php echo e($brand->brand); ?>">Edit</button> | 

                                <!-- Tombol Delete -->
                                <form action="<?php echo e(route('brands.destroy', $brand->id_brand)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Tambah Merk -->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addModalLabel">Tambah Merk</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Form Tambah di Modal -->
                <form action="<?php echo e(route('brands.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="id_brand">ID Merk</label>
                        <input type="text" id="id_brand" name="id_brand" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="brand">Nama Merk</label>
                        <input type="text" id="brand" name="brand" class="form-control" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit Merk</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- Form Edit di Modal -->
                <form action="<?php echo e(route('brands.update', 'brand_id')); ?>" method="POST" id="editForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <div class="form-group">
                        <label for="id_brand">ID Merk</label>
                        <input type="text" id="id_brand" name="id_brand" class="form-control" required readonly>
                    </div>

                    <div class="form-group">
                        <label for="brand">Nama Merk</label>
                        <input type="text" id="brand" name="brand" class="form-control" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Script untuk Bootstrap dan jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>

<script>
    // Mengisi data modal dengan data merk yang akan diedit
    $('#editModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Tombol Edit yang diklik
        var id = button.data('id') // Ambil ID merk
        var nama = button.data('nama') // Ambil nama merk

        // Set data ke form di modal
        var modal = $(this)
        modal.find('#id_brand').val(id)
        modal.find('#brand').val(nama)

        // Update action URL pada form edit
        var actionUrl = "<?php echo e(route('brands.update', ':id')); ?>";
        actionUrl = actionUrl.replace(':id', id);
        modal.find('#editForm').attr('action', actionUrl);
    })
</script>

</body>
</html>
<?php /**PATH C:\laragon\www\sistem_inka\resources\views/brands.blade.php ENDPATH**/ ?>