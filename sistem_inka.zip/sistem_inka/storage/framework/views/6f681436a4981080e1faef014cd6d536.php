<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barang | Sistem Inventory dan Kasir</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-all">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Data Barang</h2>
        <div class="mb-4">
            <form action="<?php echo e(route('items.index')); ?>" method="GET">
                <input type="text" class="form-control" placeholder="Cari Barang..." name="q" value="<?php echo e(request('q')); ?>" style="width: 300px;">
                <button type="submit" class="btn-src">Search</button>
            </form>
        </div><br>
        <button type="button" class="btn-add1" data-toggle="modal" data-target="#addItemModal">
            Tambah Data
        </button>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Id Produk</th>
                    <th>Nama Produk</th>
                    <th>Kategori</th>
                    <th>Brand</th>
                    <th>Stok</th>
                    <th>Satuan</th>
                    <th>FSN</th>
                    <th>Harga Beli</th>
                    <th>Harga Jual</th>
                    <th>Diskon</th>
                    <th>Harga Diskon</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id_produk); ?></td>
                    <td><?php echo e($item->nama_produk); ?></td>
                    <td><?php echo e($item->kategori->kategori); ?></td>
                    <td><?php echo e($item->brand->brand); ?></td>
                    <td><?php echo e($item->stok); ?></td> 
                    <td><?php echo e($item->satuan); ?></td>
                    <td><?php echo e($item->FSN); ?></td>
                    <td>Rp.<?php echo e(number_format($item->modal)); ?></td>
                    <td>Rp.<?php echo e(number_format($item->harga_jual)); ?></td>
                    <td><?php echo e($item->diskon); ?>%</td>
                    <td>Rp.<?php echo e(number_format($item->harga_setelah_diskon)); ?></td>
                     <!-- Menampilkan harga setelah diskon -->
                    <td>
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editItemModal<?php echo e($item->id_produk); ?>">Edit</button>
                        <button type="button" class="btn btn-danger btn-sm" onclick="confirmDelete('<?php echo e($item->id_produk); ?>')">Hapus</button>
                        <form id="delete-form-<?php echo e($item->id_produk); ?>" action="<?php echo e(route('items.destroy', $item->id_produk)); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal untuk Tambah Item -->
<div class="modal fade" id="addItemModal" tabindex="-1" role="dialog" aria-labelledby="addItemModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addItemModalLabel">Tambah Item</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('items.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nama_produk">Nama Produk</label>
                        <input type="text" class="form-control" id="nama_produk" name="nama_produk" required>
                    </div>
                    <div class="form-group">
                        <label for="id_kategori">Kategori</label>
                        <select class="form-control" id="id_kategori" name="id_kategori" required>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id_kategori); ?>"><?php echo e($category->kategori); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="id_brand">Brand</label>
                        <select class="form-control" id="id_brand" name="id_brand" required>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($brand->id_brand); ?>"><?php echo e($brand->brand); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="harga_jual">Harga Jual</label>
                        <input type="number" class="form-control" id="harga_jual" name="harga_jual" required>
                    </div>
                    <div class="form-group">
                        <label for="stok">Stok</label>
                        <input type="number" class="form-control" id="stok" name="stok" required>
                    </div>
                    <div class="form-group">
                        <label for="satuan">Satuan</label>
                        <input type="text" class="form-control" id="satuan" name="satuan" required>
                    </div>
                    <div class="form-group">
                        <label for="modal">Modal</label>
                        <input type="number" class="form-control" id="modal" name="modal" required>
                    </div>
                    <div class="form-group">
                        <label for="FSN">FSN</label>
                        <select class="form-control" id="FSN" name="FSN" required>
                            <option value="F">F</option>
                            <option value="S">S</option>
                            <option value="N">N</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="diskon">Diskon</label>
                        <input type="number" class="form-control" id="diskon" name="diskon" required>
                    </div>
                    <button type="submit" class="btn btn-success">Tambah</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal untuk Edit Item -->
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="editItemModal<?php echo e($item->id_produk); ?>" tabindex="-1" role="dialog" aria-labelledby="editItemModalLabel<?php echo e($item->id_produk); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editItemModalLabel<?php echo e($item->id_produk); ?>">Edit Item</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('items.update', $item->id_produk)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="nama_produk">Nama Produk</label>
                        <input type="text" class="form-control" id="nama_produk" name="nama_produk" value="<?php echo e($item->nama_produk); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="id_kategori">Kategori</label>
                        <select class="form-control" id="id_kategori" name="id_kategori" required>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id_kategori); ?>" <?php echo e($category->id_kategori == $item->id_kategori ? 'selected' : ''); ?>>
                                <?php echo e($category->kategori); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="id_brand">Brand</label>
                        <select class="form-control" id="id_brand" name="id_brand" required>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($brand->id_brand); ?>" <?php echo e($brand->id_brand == $item->id_brand ? 'selected' : ''); ?>>
                                <?php echo e($brand->brand); ?>

                            </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="harga_jual">Harga Jual</label>
                        <input type="number" class="form-control" id="harga_jual" name="harga_jual" value="<?php echo e($item->harga_jual); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="stok">Stok</label>
                        <input type="number" class="form-control" id="stok" name="stok" value="<?php echo e($item->stok); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="satuan">Satuan</label>
                        <input type="text" class="form-control" id="satuan" name="satuan" value="<?php echo e($item->satuan); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="modal">Modal</label>
                        <input type="number" class="form-control" id="modal" name="modal" value="<?php echo e($item->modal); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="FSN">FSN</label>
                        <select class="form-control" id="FSN" name="FSN" required>
                            <option value="F" <?php echo e($item->FSN == 'F' ? 'selected' : ''); ?>>F</option>
                            <option value="S" <?php echo e($item->FSN == 'S' ? 'selected' : ''); ?>>S</option>
                            <option value="N" <?php echo e($item->FSN == 'N' ? 'selected' : ''); ?>>N</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="diskon">Diskon</label>
                        <input type="number" class="form-control" id="diskon" name="diskon" value="<?php echo e($item->diskon); ?>" required>
                    </div>
                    <button type="submit" class="btn btn-success">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- SweetAlert for success -->
<?php if(session('success')): ?>
<script>
    Swal.fire({
        icon: 'success',
        title: 'Berhasil',
        text: '<?php echo e(session('success')); ?>',
        timer: 2000,
        showConfirmButton: false
    })
</script>
<?php endif; ?>

<script>
    function confirmDelete(id) {
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Data ini akan dihapus!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                document.getElementById('delete-form-' + id).submit(); // Mengirim form penghapusan
            }
        });
    }
</script>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH C:\laragon\www\sistem_inka\resources\views/item.blade.php ENDPATH**/ ?>