<?php echo $__env->yieldContent('content'); ?>

<head>
    <!-- Link CDN untuk Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>

<div class="sidebar1">
    <div class="user-info">
        <img src="https://www.w3schools.com/w3images/avatar2.png" alt="User" class="user-avatar">
         <p><?php echo e(Auth::user()->nama_user); ?></p> <!-- Mengambil nama_user dari pengguna yang login -->
    </div>
    <nav>
        <ul>
            <li><a href="<?php echo e(route('dashboard')); ?>"><i class="bi bi-house-door"></i>Dashboard</a></li>
            <li><a href="<?php echo e(route('categories.index')); ?>"><i class="bi bi-tag"></i>Kategori</a></li>
            <li><a href="<?php echo e(route('brands.index')); ?>"><i class="bi bi-box-seam"></i>Brand</a></li>
            <li><a href="<?php echo e(route('items.index')); ?>"><i class="bi bi-box"></i>Barang</a></li>
            <li><a href="<?php echo e(route('services.index')); ?>"><i class="bi bi-gear"></i>Service</a></li>
            <li><a href="<?php echo e(route('users.index')); ?>"><i class="bi bi-person"></i>Pengguna</a></li>
            <li><a href="#"><i class="bi bi-file-earmark-spreadsheet"></i>Laporan Keuangan</a></li>
        </ul>

        <ul>
            <li><a href="<?php echo e(route('dashboard_kasir')); ?>"><i class="bi bi-house-door"></i> Dashboard</a></li>
            <li><a href="<?php echo e(route('sale.index')); ?>"><i class="bi bi-cart-fill"></i> Transaksi</a></li>
            <li><a href="<?php echo e(route('sale.history')); ?>"><i class="bi bi-clock-history"></i> History</a></li>
        </ul>
    </nav>
</div>  <?php /**PATH C:\laragon\www\sistem_inka\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>