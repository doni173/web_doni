<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barang | Sistem Inventory dan Kasir</title>

    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="dashboard-container">
    <div class="container">
        <h2 class="mb-4">Daftar Barang</h2>

        <!-- Form Pencarian -->
        <div class="input-group mb-4">
            <form action="<?php echo e(route('items.index')); ?>" method="GET" class="form-inline">
                <input type="text" name="search" class="form-control mr-2"
                    placeholder="Cari nama barang..."
                    value="<?php echo e(request('search')); ?>">
                <button class="btn btn-primary">Cari</button>
            </form>
            <div class="add-button-container mt-3">
                <button class="btn btn-success" data-toggle="modal" data-target="#addModal">
                    Tambah Data
                </button>
            </div>
        </div>

        <!-- Tabel Items -->
        <div class="category-table-container">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID Produk</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th>Brand</th>
                        <th>Satuan</th>
                        <th>Modal</th>
                        <th>Harga Jual</th>
                        <th>Stok</th>
                        <th>FSN</th>
                        <th>Diskon (%)</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->Id_Produk); ?></td>
                        <td><?php echo e($item->Nama_Produk); ?></td>
                        <td><?php echo e($item->kategori->Kategori ?? '-'); ?></td>
                        <td><?php echo e($item->brand->Brand ?? '-'); ?></td>
                        <td><?php echo e($item->Satuan); ?></td>
                        <td><?php echo e(number_format($item->Modal)); ?></td>
                        <td><?php echo e(number_format($item->Harga_Jual)); ?></td>
                        <td><?php echo e($item->Stok); ?></td>
                        <td><?php echo e($item->FSN); ?></td>
                        <td><?php echo e($item->Diskon); ?></td>
                        <td>
                            <!-- Tombol Edit untuk membuka modal -->
                            <button class="btn btn-warning btn-sm"
                                data-toggle="modal"
                                data-target="#editModal"
                                data-item='<?php echo json_encode($item, 15, 512) ?>'>
                                Edit
                            </button>

                            <!-- Tombol Delete -->
                            <form action="<?php echo e(route('items.destroy', $item->Id_Produk)); ?>"
                                method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin hapus data?')">
                                    Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<!-- ================= MODAL TAMBAH ================= -->
<div class="modal fade" id="addModal">
    <div class="modal-dialog modal-lg">
        <form action="<?php echo e(route('items.store')); ?>" method="POST" class="modal-content">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h5 class="modal-title">Tambah Barang</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <div class="modal-body row">
                <div class="col-md-6">
                    <label>ID Produk</label>
                    <input type="text" name="Id_Produk" class="form-control" required>

                    <label class="mt-2">Nama Produk</label>
                    <input type="text" name="Nama_Produk" class="form-control" required>

                    <label class="mt-2">Kategori</label>
                    <select name="Id_Kategori" class="form-control" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id_Kategori); ?>"><?php echo e($c->kategori); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <label class="mt-2">Brand</label>
                    <select name="Id_brand" class="form-control" required>
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($b->id_brand); ?>"><?php echo e($b->id_brand); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label>Satuan</label>
                    <input type="text" name="Satuan" class="form-control">

                    <label class="mt-2">Modal</label>
                    <input type="number" name="Modal" class="form-control">

                    <label class="mt-2">Harga Jual</label>
                    <input type="number" name="Harga_Jual" class="form-control">

                    <label class="mt-2">Stok</label>
                    <input type="number" name="Stok" class="form-control">

                    <label class="mt-2">FSN</label>
                    <select name="FSN" class="form-control">
                        <option value="F">Fast</option>
                        <option value="S">Slow</option>
                        <option value="N">Non Moving</option>
                    </select>

                    <label class="mt-2">Diskon (%)</label>
                    <input type="number" step="0.01" name="Diskon" class="form-control">
                </div>
            </div>

            <div class="modal-footer">
                <button class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- ================= SCRIPT ================= -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>

<script>
$('#editModal').on('show.bs.modal', function (e) {
    let item = $(e.relatedTarget).data('item');
    let form = $(this).find('form');

    form.attr('action', '/items/' + item.Id_Produk);

    Object.keys(item).forEach(key => {
        form.find('[name="'+key+'"]').val(item[key]);
    });
});
</script>

</body>
</html>
<?php /**PATH C:\laragon\www\sistem_inka\resources\views/items.blade.php ENDPATH**/ ?>