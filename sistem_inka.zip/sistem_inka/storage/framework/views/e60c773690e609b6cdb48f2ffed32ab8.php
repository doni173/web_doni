<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi | Sistem Inventory dan Kasir</title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-all">
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Transaksi Penjualan</h2>
        </div>
        <!-- Wrapper untuk tabel Daftar Barang dan Daftar Service -->
        <div class="table-wrapper">
            <!-- Daftar Barang -->
            <div class="table-container">
                <h3>Daftar Barang</h3>
                <form action="<?php echo e(route('transaction.index')); ?>" method="GET" class="search-form">
                    <input type="text" class="form-control" placeholder="Cari barang..." name="q" value="<?php echo e(request('q')); ?>" style="width: 300px;">
                    <button type="submit" class="btn-src">Search</button>
                </form>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Produk</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->nama_produk); ?></td>
                            <td><?php echo e(number_format($item->harga_jual, 0, ',', '.')); ?></td>
                            <td>
                                <input type="number" name="qty" class="form-control qty" data-id="<?php echo e($item->id_produk); ?>" value="1" min="1" max="100">
                            </td>
                            <td>
                                <button class="btn btn-success add-item" data-id="<?php echo e($item->id_produk); ?>" data-name="<?php echo e($item->nama_produk); ?>" data-price="<?php echo e($item->harga_jual); ?>">Tambah</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- Daftar Service -->
            <div class="table-container">
                <h3>Daftar Service</h3>
                <form action="<?php echo e(route('transaction.index')); ?>" method="GET" class="search-form">
                    <input type="text" class="form-control" placeholder="Cari service..." name="q" value="<?php echo e(request('q')); ?>" style="width: 300px;">
                    <button type="submit" class="btn-src">Search</button>
                </form>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Service</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($service->service); ?></td>
                            <td><?php echo e(number_format($service->harga, 0, ',', '.')); ?></td>
                            <td>
                                <input type="number" name="qty" class="form-control qty" data-id="<?php echo e($service->id_service); ?>" value="1" min="1" max="100">
                            </td>
                            <td>
                                <button class="btn btn-success add-service" data-id="<?php echo e($service->id_service); ?>" data-name="<?php echo e($service->service); ?>" data-price="<?php echo e($service->harga); ?>">Tambah</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- Ringkasan Transaksi -->
        <h3>Ringkasan Transaksi</h3>
        <form action="<?php echo e(route('transaction.store')); ?>" method="POST" id="transaction-form">
            <?php echo csrf_field(); ?>
            <table class="table table-striped" id="summary-table">
                <thead>
                    <tr>
                        <th>Produk / Service</th>
                        <th>Harga</th>
                        <th>Jumlah</th>
                        <th>Total Harga</th>
                    </tr>
                </thead>
                <tbody id="summary-body">
                    <!-- Data yang ditambahkan akan muncul di sini -->
                </tbody>
            </table>

            <div class="form-group">
                <h4>Total Belanja: <span id="total_harga">Rp. 0</span></h4>
            </div>


            <div class="form-group">
                <label for="jumlah_bayar">Jumlah Bayar</label>
                <input type="number" id="jumlah_bayar" name="jumlah_bayar" class="form-control" required>
            </div>

            <div class="form-group">
                <h4>Kembalian: <span id="kembalian">Rp. 0</span></h4>
            </div>

            <button type="submit" class="btn btn-primary">Selesaikan Transaksi</button>
        </form>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    /* General Styles */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f4f4;
        color: #333;
    }

    .container-all {
        margin-top: 30px;
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .table-wrapper {
        display: flex;
        justify-content: space-between;
        gap: 20px;
    }

    .table-container {
        flex: 1;
    }

    .table {
        width: 100%;
        margin-top: 20px;
        border-collapse: collapse;
    }

    .table-striped tr:nth-child(odd) {
        background-color: #f9f9f9;
    }

    .table th, .table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .table th {
        background-color: #007bff;
        color: #fff;
    }

    .btn-success {
        background-color: #28a745;
        color: white;
    }

    .btn-success:hover {
        background-color: #218838;
    }

    .btn-src {
        background-color: #007bff;
        color: white;
    }

    .btn-src:hover {
        background-color: #0056b3;
    }

    .form-control {
        width: 100%;
        padding: 8px;
        font-size: 16px;
    }
</style>
<script>
document.addEventListener('DOMContentLoaded', function () {

    let cart = [];
    let totalBelanja = 0;

    function updateSummary() {
        totalBelanja = 0;
        const tbody = document.getElementById('summary-body');
        tbody.innerHTML = '';

        cart.forEach(item => {
            const totalItem = item.price * item.qty;
            totalBelanja += totalItem;

            tbody.innerHTML += `
                <tr>
                    <td>${item.name}</td>
                    <td>Rp ${item.price.toLocaleString('id-ID')}</td>
                    <td>${item.qty}</td>
                    <td>Rp ${totalItem.toLocaleString('id-ID')}</td>
                </tr>
            `;
        });

        document.getElementById('total_harga').innerText =
            'Rp. ' + totalBelanja.toLocaleString('id-ID');

        hitungKembalian();
    }

    function addToCart(id, name, price, qty) {
        const existing = cart.find(item => item.id === id);

        if (existing) {
            existing.qty += qty;
        } else {
            cart.push({ id, name, price, qty });
        }

        updateSummary();
    }

    function hitungKembalian() {
        const bayar =
            parseInt(document.getElementById('jumlah_bayar').value) || 0;

        let kembali = bayar - totalBelanja;
        if (kembali < 0) kembali = 0;

        document.getElementById('kembalian').innerText =
            'Rp. ' + kembali.toLocaleString('id-ID');
    }

    document.getElementById('jumlah_bayar')
        .addEventListener('input', hitungKembalian);

    // ITEM
    document.querySelectorAll('.add-item').forEach(btn => {
        btn.addEventListener('click', function () {
            const tr = this.closest('tr');
            const qty = parseInt(tr.querySelector('.qty').value);

            addToCart(
                this.dataset.id,
                this.dataset.name,
                parseInt(this.dataset.price),
                qty
            );
        });
    });

    // SERVICE
    document.querySelectorAll('.add-service').forEach(btn => {
        btn.addEventListener('click', function () {
            const tr = this.closest('tr');
            const qty = parseInt(tr.querySelector('.qty').value);

            addToCart(
                this.dataset.id,
                this.dataset.name,
                parseInt(this.dataset.price),
                qty
            );
        });
    });

});
</script>


</body>
</html><?php /**PATH C:\laragon\www\sistem_inka\resources\views/transaction.blade.php ENDPATH**/ ?>