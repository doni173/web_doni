<table class="table table-bordered">
    <thead>
        <tr>
            <th>Id Kategori</th>
            <th>Kategori</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        @forelse($categories as $category)
            <tr>
                <td>{{ $category->id_kategori }}</td>
                <td>{{ $category->kategori }}</td>
                <td>
                    <!-- Tombol Edit -->
                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editCategoryModal{{ $category->id_kategori }}">
                        Edit
                    </button>

                    <!-- Tombol Hapus -->
                    <button type="button" class="btn btn-danger btn-sm" onclick="confirmDelete('{{ $category->id_kategori }}')">
                        Hapus
                    </button>

                    <!-- Form Penghapusan -->
                    <form id="delete-form-{{ $category->id_kategori }}" action="{{ route('categories.destroy', $category->id_kategori) }}" method="POST" style="display: none;">
                        @csrf
                        @method('DELETE')
                    </form>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="3" class="text-center">Tidak ada kategori ditemukan</td>
            </tr>
        @endforelse
    </tbody>
</table>
