<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History Penjualan | Sistem Inventory dan Kasir</title>
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
</head>
<body>
@include('layouts.sidebar')
@include('layouts.navbar')
<div class="container-all">
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>History Penjualan</h2>
        </div>
        
        <!-- Tabel Daftar Transaksi -->
        <div class="table-wrapper">
            <div class="table-container">
                <h3>Daftar Transaksi</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID Detail</th>
                            <th>Nama Produk</th>
                            <th>Total Harga</th>
                            <th>Tanggal Penjualan</th>
                            <th>Status Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($sales as $sale)
                        <tr>
                            <td>{{ $sale->id_penjualan }}</td>
                            <td>{{ $sale->customer_name }}</td>
                            <td>{{ number_format($sale->total_bayar, 0, ',', '.') }}</td>
                            <td>{{ $sale->tgl_penjualan }}</td>
                            <td>{{ $sale->jumlah_bayar >= $sale->total_bayar ? 'Lunas' : 'Belum Lunas' }}</td>
                            <td>
                                <a href="{{ route('sale.show', $sale->id_penjualan) }}" class="btn btn-info btn-sm">Detail</a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
    /* General Styles */
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f4f4f4;
        color: #333;
    }

    .container-all {
        margin-top: 30px;
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .table-wrapper {
        margin-top: 20px;
    }

    .table-container {
        margin-bottom: 20px;
    }

    .table {
        width: 100%;
        margin-top: 20px;
        border-collapse: collapse;
    }

    .table-striped tr:nth-child(odd) {
        background-color: #f9f9f9;
    }

    .table th, .table td {
        padding: 12px 15px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }

    .table th {
        background-color: #007bff;
        color: #fff;
    }

    .btn-info {
        background-color: #17a2b8;
        color: white;
    }

    .btn-info:hover {
        background-color: #138496;
    }
</style>
@endpush

</body>
</html>
