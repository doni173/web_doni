<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    protected $table = 'sales';
protected $primaryKey = 'id_penjualan'; 
 public $incrementing = true;
    protected $keyType = 'int';
    protected $fillable = [
        'id_user',
        'id_penjualan',
        'id_pelanggan',
        'total_belanja',
        'jumlah_bayar',
        'kembalian',
        'tanggal_transaksi'
    ];
}


