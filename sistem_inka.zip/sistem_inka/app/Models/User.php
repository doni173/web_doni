<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model;

class User extends Authenticatable
{
    use HasFactory;

    // Menentukan nama tabel
    protected $table = 'users';

    // Kolom yang dapat diisi
    protected $fillable = [
        'id_user','nama_user','username', 'password', 'role', 
    ];

    // Kolom yang harus disembunyikan
    protected $hidden = [
        'password', 'remember_token',
    ];

    // Menentukan primary key dan mengatur tipe
    protected $primaryKey = 'id_user';  // Primary key yang digunakan
    public $incrementing = false;  // Karena 'id_user' auto-increment
    
    // Enkripsi password saat menyimpan data
    public static function boot()
    {
        parent::boot();

        static::creating(function ($user) {
            if ($user->password) {
                // Enkripsi password jika disediakan
                $user->password = bcrypt($user->password);
            }
        });
    }
}
