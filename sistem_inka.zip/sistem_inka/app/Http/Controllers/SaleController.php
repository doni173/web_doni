<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Service;
use App\Models\Sale;
use App\Models\SaleDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SaleController extends Controller
{
    // Menampilkan halaman penjualan
    public function index(Request $request)
    {
        $q_barang = $request->query('q_barang');  
        $q_service = $request->query('q_service');  

        $items = Item::when($q_barang, function ($query) use ($q_barang) {
            return $query->where('nama_produk', 'like', "%{$q_barang}%");
        })->get();

        $services = Service::when($q_service, function ($query) use ($q_service) {
            return $query->where('service', 'like', "%{$q_service}%");
        })->get();

        return view('sale', compact('items', 'services'));
    }

    // Menyelesaikan penjualan
    public function store(Request $request)
    {
        $request->validate([
            'nama_pelanggan' => 'required|string',
            'jumlah_bayar' => 'required|numeric',
            'total_belanja' => 'required|numeric',
            'cart_data' => 'required|string',
        ]);

        $cart = json_decode($request->cart_data, true);

        if (!$cart || count($cart) === 0) {
            return back()->with('error', 'Keranjang kosong!');
        }

        $sale = Sale::create([
            'tanggal_transaksi' => now(),
            'id_user' => Auth::id(),
            'id_pelanggan' => $request->nama_pelanggan,
            'total_belanja' => $request->total_belanja,
            'jumlah_bayar' => $request->jumlah_bayar,
            'kembalian' => $request->jumlah_bayar - $request->total_belanja,
        ]);

        foreach ($cart as $item) {
            SaleDetail::create([
                'id_penjualan' => $sale->id_penjualan,
                'id_produk' => $item['id_produk'] ?? null,
                'id_service' => $item['id_service'] ?? null,
                'jumlah' => $item['jumlah'],
                'harga' => $item['harga'],
                'diskon' => $item['diskon'] ?? 0,
                'harga_setelah_diskon' => $item['harga_setelah_diskon'],
                'total' => $item['harga_setelah_diskon'] * $item['jumlah'],
            ]);
        }

        return redirect()->route('sale.index')->with('success', 'Transaksi berhasil disimpan!');
    }
}
